## How It's Made: 
This is a Chat application concept design. 
First designed in Figma, then developed in Webflow. 
Responvive design with basic hover and page load animations.


## Preview
![image](https://user-images.githubusercontent.com/64226925/234437413-e0900b5b-696e-4c70-b226-7fd5e74af96f.png)
![image](https://user-images.githubusercontent.com/64226925/234437493-1797fa22-04ec-4a2c-8572-e4d9eb627ddd.png)
![image](https://user-images.githubusercontent.com/64226925/234437532-67cae30c-6372-46d1-8958-7e52aff6edab.png)
![image](https://user-images.githubusercontent.com/64226925/234437590-161c25c8-5a28-416e-afb9-02b4ce7831b7.png)
![image](https://user-images.githubusercontent.com/64226925/234437667-f66e5969-7978-44ab-bfa4-e44a0f4dadbe.png)
![image](https://user-images.githubusercontent.com/64226925/234437711-577daaf2-cf40-405e-928d-b68d43cb6c04.png)
